use axum::{
    extract::{Multipart, Query},
    http::{header, StatusCode},
    response::{IntoResponse, Response},
    routing::{get, post},
    Router,
};
use tokio::net::TcpListener;
use tower_http::cors::CorsLayer;
use tower_http::limit::RequestBodyLimitLayer;

mod services;
use services::pdf::PdfEngine;

#[derive(serde::Deserialize)]
struct SplitQuery {
    pages: String,
}

#[derive(serde::Deserialize)]
struct ResizerQuery {
    target_kb: usize,
    max_w: u32,
    max_h: u32,
}

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt::init();

    let app = Router::new()
        .route("/health", get(|| async { "Healthy - BharatPDF Engine" }))
        .route("/api/v1/merge", post(handle_merge))
        .route("/api/v1/split", post(handle_split))
        .route("/api/v1/sarkari-resizer", post(handle_sarkari_resizer))
        .layer(RequestBodyLimitLayer::new(100 * 1024 * 1024))
        .layer(CorsLayer::permissive());

    let listener = TcpListener::bind("0.0.0.0:8080").await.unwrap();
    println!("🚀 BharatPDF Rust Backend running on http://0.0.0.0:8080");
    axum::serve(listener, app).await.unwrap();
}

async fn handle_merge(mut multipart: Multipart) -> Result<Response, (StatusCode, String)> {
    let mut files = Vec::new();
    while let Some(field) = multipart.next_field().await.map_err(|e| (StatusCode::BAD_REQUEST, e.to_string()))? {
        let bytes = field.bytes().await.map_err(|e| (StatusCode::BAD_REQUEST, e.to_string()))?;
        files.push(bytes.to_vec());
    }

    if files.is_empty() {
        return Err((StatusCode::BAD_REQUEST, "No files supplied".to_string()));
    }

    let result = tokio::task::spawn_blocking(move || PdfEngine::merge(files))
        .await
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?
        .map_err(|e| (StatusCode::UNPROCESSABLE_ENTITY, e.to_string()))?;

    Ok((
        [
            (header::CONTENT_TYPE, "application/pdf"),
            (header::CONTENT_DISPOSITION, "attachment; filename="merged.pdf""),
        ],
        result,
    ).into_response())
}

async fn handle_split(Query(q): Query<SplitQuery>, mut multipart: Multipart) -> Result<Response, (StatusCode, String)> {
    let mut file_bytes = None;
    while let Some(field) = multipart.next_field().await.map_err(|e| (StatusCode::BAD_REQUEST, e.to_string()))? {
        file_bytes = Some(field.bytes().await.map_err(|e| (StatusCode::BAD_REQUEST, e.to_string()))?.to_vec());
        break;
    }

    let bytes = file_bytes.ok_or((StatusCode::BAD_REQUEST, "No PDF file provided".to_string()))?;
    let pages: Vec<u32> = q.pages.split(',').filter_map(|s| s.trim().parse::<u32>().ok()).collect();

    let result = tokio::task::spawn_blocking(move || PdfEngine::split(&bytes, &pages))
        .await
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?
        .map_err(|e| (StatusCode::UNPROCESSABLE_ENTITY, e.to_string()))?;

    Ok((
        [
            (header::CONTENT_TYPE, "application/pdf"),
            (header::CONTENT_DISPOSITION, "attachment; filename="split.pdf""),
        ],
        result,
    ).into_response())
}

async fn handle_sarkari_resizer(Query(q): Query<ResizerQuery>, mut multipart: Multipart) -> Result<Response, (StatusCode, String)> {
    let mut file_bytes = None;
    while let Some(field) = multipart.next_field().await.map_err(|e| (StatusCode::BAD_REQUEST, e.to_string()))? {
        file_bytes = Some(field.bytes().await.map_err(|e| (StatusCode::BAD_REQUEST, e.to_string()))?.to_vec());
        break;
    }

    let bytes = file_bytes.ok_or((StatusCode::BAD_REQUEST, "No image uploaded".to_string()))?;
    let result = tokio::task::spawn_blocking(move || {
        PdfEngine::crunch_image_to_kb(&bytes, q.target_kb, q.max_w, q.max_h)
    })
    .await
    .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?
    .map_err(|e| (StatusCode::UNPROCESSABLE_ENTITY, e.to_string()))?;

    Ok((
        [
            (header::CONTENT_TYPE, "image/jpeg"),
            (header::CONTENT_DISPOSITION, "attachment; filename="sarkari_compliant.jpg""),
        ],
        result,
    ).into_response())
}
