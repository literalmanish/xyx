use lopdf::{Document, Object};
use std::collections::BTreeMap;
use std::io::Cursor;

pub struct PdfEngine;

impl PdfEngine {
    pub fn merge(pdf_buffers: Vec<Vec<u8>>) -> Result<Vec<u8>, lopdf::Error> {
        let mut max_id = 1;
        let mut documents = Vec::new();

        for buf in &pdf_buffers {
            let doc = Document::load_mem(buf)?;
            documents.push(doc);
        }

        let mut final_doc = Document::with_version("1.7");
        let mut pages = BTreeMap::new();

        for mut doc in documents {
            doc.renumber_objects_with(max_id);
            max_id = doc.max_id + 1;

            for (id, object) in doc.objects {
                final_doc.objects.insert(id, object);
            }

            for (_, page_id) in doc.get_pages() {
                pages.insert(pages.len() as u32 + 1, page_id);
            }
        }

        let catalog_id = final_doc.new_object_id();
        let pages_id = final_doc.new_object_id();
        let count = pages.len() as i64;
        let kids: Vec<Object> = pages.values().map(|&id| Object::Reference(id)).collect();

        final_doc.objects.insert(
            pages_id,
            lopdf::dictionary! {
                "Type" => "Pages",
                "Count" => count,
                "Kids" => kids,
            }.into(),
        );

        final_doc.objects.insert(
            catalog_id,
            lopdf::dictionary! {
                "Type" => "Catalog",
                "Pages" => pages_id,
            }.into(),
        );

        final_doc.trailer.set("Root", catalog_id);
        final_doc.compress();

        let mut out = Vec::new();
        final_doc.save_to(&mut out)?;
        Ok(out)
    }

    pub fn split(pdf_buffer: &[u8], page_numbers: &[u32]) -> Result<Vec<u8>, lopdf::Error> {
        let mut doc = Document::load_mem(pdf_buffer)?;
        let total_pages = doc.get_pages();
        let mut pages_to_delete = Vec::new();

        for (&page_num, _) in &total_pages {
            if !page_numbers.contains(&page_num) {
                pages_to_delete.push(page_num);
            }
        }

        pages_to_delete.sort_by(|a, b| b.cmp(a));
        for page_num in pages_to_delete {
            doc.delete_pages(&[page_num]);
        }

        doc.prune_objects();
        doc.compress();

        let mut out = Vec::new();
        doc.save_to(&mut out)?;
        Ok(out)
    }

    pub fn crunch_image_to_kb(raw_bytes: &[u8], target_kb: usize, max_w: u32, max_h: u32) -> Result<Vec<u8>, image::ImageError> {
        let img = image::load_from_memory(raw_bytes)?;
        let resized = img.resize(max_w, max_h, image::imageops::FilterType::Lanczos3);

        let mut min_q = 5u8;
        let mut max_q = 95u8;
        let mut best_bytes = Vec::new();

        for _ in 0..7 {
            let mid_q = (min_q + max_q) / 2;
            let mut buf = Cursor::new(Vec::new());

            let mut encoder = image::codecs::jpeg::JpegEncoder::new_with_quality(&mut buf, mid_q);
            encoder.encode_image(&resized)?;

            let size_kb = buf.get_ref().len() / 1024;
            if size_kb <= target_kb {
                best_bytes = buf.into_inner();
                min_q = mid_q + 1;
            } else {
                max_q = mid_q.saturating_sub(1);
            }
        }

        if best_bytes.is_empty() {
            let mut buf = Cursor::new(Vec::new());
            let mut encoder = image::codecs::jpeg::JpegEncoder::new_with_quality(&mut buf, 5);
            encoder.encode_image(&resized)?;
            best_bytes = buf.into_inner();
        }

        Ok(best_bytes)
    }
}
