# BharatPDF (Desi Document Platform)

A 32-in-1 client-side and cloud-capable document manipulation platform tailored for Indian workflows.

## Directory Structure
- `frontend/`: Standalone mobile-responsive single-page app and Android wrapper.
- `backend/`: High-performance Axum/Tokio Rust microservice.
- `.github/workflows/`: CI/CD pipelines for automated APK builds and static site deployment.
